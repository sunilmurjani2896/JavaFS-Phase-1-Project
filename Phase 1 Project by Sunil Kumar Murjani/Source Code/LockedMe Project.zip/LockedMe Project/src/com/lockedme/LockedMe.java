package com.lockedme;
import java.io.*;
import java.util.*;

public class LockedMe {
	static final String projectFilesPath="D:\\SimpliLearn\\LiveSessions\\Phase 1\\2022-01-22\\LockedMeFiles";
	static final String errorMessage="Some error occured. Please contact : admin@lockedme.com";
	public static void main(String[] args) 
	{	Scanner obj=new Scanner(System.in);		
		int choice;
		do
		{	displayMenu();
			System.out.println("Enter your choice b/w 1 to 5");
			try {
			choice=Integer.parseInt(obj.nextLine());
			switch(choice)
					{	case 1:getAllFiles();
							break;
						case 2:createFile();
							break;
						case 3:deleteFile();
							break;
						case 4:searchFile();
							break;
						case 5:System.exit(0);
							break;
						default:System.out.println("Invalid input");;
							break;
				
					}
			}
			catch(Exception ex)
			{System.out.println("enter integer only");
			choice=1;
				}
			
		}while(choice>0);
		obj.close();
	}
	
	/**
	 * This method displays all the options available in the menu
	 */
	public static void displayMenu()
	{	System.out.println("**************************************************");
		System.out.println("  WELCOME TO LOCKEDME.COM");
		System.out.println("Created By - Sunil Kumar Murjani");
		System.out.println("**************************************************");
		System.out.println("\t1. Display all files");
		System.out.println("\t2. Create a file");
		System.out.println("\t3. Delete a file");
		System.out.println("\t4. Search a file");
		System.out.println("\t5. Exit");
	}
	/**
	 * This method will return all the files from the project directory
	 */
	public static void getAllFiles()
	{	try
		{	File folder=new File(projectFilesPath);
			File[] listOfFiles=folder.listFiles();
			if(listOfFiles.length==0)
				System.out.println("no file exists");
			else
				for(var l:listOfFiles)
					System.out.println(l.getName());
		}
		catch(Exception ex)
			{	System.out.println(errorMessage);
			}
	}
	/**
	 * This method will create the file based on file name provided by the user
	 */
	public static void createFile()
	{	try
		{	Scanner obj=new Scanner(System.in);
			System.out.println("Enter file name which is to be created");
			String fileName=obj.nextLine();
			System.out.println("Enter number of lines to be entered");
			int linesCount=Integer.parseInt(obj.nextLine());
			
			FileWriter fw=new FileWriter(projectFilesPath+"\\"+fileName);
			for(int i=1; i<=linesCount;i++)
			{	System.out.println("Enter line number : "+i);
				fw.write(obj.nextLine()+"\n");
			}
			System.out.println("File created successfully");
			fw.close();
		}
		catch(Exception ex)
		{	System.out.println(errorMessage);
		}
	}
	/**
	 * This method will delete the file based on file name provided by the user
	 */
	public static void deleteFile()
	{	try
		{	Scanner obj=new Scanner(System.in);
			System.out.println("Enter file name which is to be deleted");
			String fileName=obj.nextLine();
			File file=new File(projectFilesPath+"\\"+fileName);
			if(file.exists())
			{	file.delete();
				System.out.println("File deleted successfully :"+fileName);				
			}
			else
				System.out.println("File does not exist");
		}
		catch(Exception ex)
		{	System.out.println(errorMessage);
		}
		
	}
	/**
	 * This method will search files from the directory
	 */
	public static void searchFile()
	{	try
		{	Scanner obj=new Scanner(System.in);
			System.out.println("Enter file name which is to be searched");
			String fileName=obj.nextLine();
			File folder=new File(projectFilesPath);
			File[] listOfFiles=folder.listFiles();
			
			List<String> filenames=new ArrayList<>();
			for(var l:listOfFiles)
				filenames.add(l.getName());
			if(filenames.contains(fileName))
				System.out.println("File is available");
			else
				System.out.println("File is not available");
		}
		catch(Exception ex)
			{	System.out.println(errorMessage);
			}
	}
}
